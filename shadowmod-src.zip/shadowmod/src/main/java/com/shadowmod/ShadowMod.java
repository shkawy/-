package com.shadowmod;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

import java.util.*;

public class ShadowMod implements ModInitializer {
    static MinecraftServer SERVER;
    static final Map<UUID, State> STATES = new HashMap<>();
    static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
            EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND };

    static class Frame {
        double x, y, z; float yaw, pitch;
        EntityPose pose; boolean sneak, sprint, swing;
    }

    static class State {
        UUID shadow;
        Deque<Frame> trail = new ArrayDeque<>();
        int delay = 20;        // كم تيك يتأخر الظل عنك (20 = ثانية)
        boolean mirror = false;
        double cx, cz;         // مركز المرآة
        boolean swing;
    }

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> { SERVER = s; killAll(); });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> { killAll(); STATES.clear(); });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> remove(handler.getPlayer()));
        ServerTickEvents.END_SERVER_TICK.register(this::tick);

        // حركة اليد (ضرب / استخدام)
        AttackBlockCallback.EVENT.register((p, w, h, pos, dir) -> { mark(p); return ActionResult.PASS; });
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> { mark(p); return ActionResult.PASS; });
        UseBlockCallback.EVENT.register((p, w, h, hit) -> { mark(p); return ActionResult.PASS; });
        UseItemCallback.EVENT.register((p, w, h) -> { mark(p); return ActionResult.PASS; });

        CommandRegistrationCallback.EVENT.register((d, reg, env) -> commands(d));
    }

    static void mark(PlayerEntity p) {
        State s = STATES.get(p.getUuid());
        if (s != null) s.swing = true;
    }

    static void run(String cmd, ServerWorld w) {
        try {
            ServerCommandSource src = SERVER.getCommandSource();
            if (w != null) src = src.withWorld(w);
            SERVER.getCommandManager().getDispatcher().execute(cmd, src);
        } catch (Exception ignored) { }
    }

    static void killAll() {
        if (SERVER != null) run("kill @e[type=minecraft:mannequin,tag=shadowmod]", null);
    }

    static void remove(ServerPlayerEntity p) {
        State s = STATES.remove(p.getUuid());
        if (s != null && s.shadow != null) run("kill " + s.shadow, null);
    }

    static void spawn(ServerPlayerEntity p, ServerWorld w, State s, Frame f) {
        if (s.shadow != null) run("kill " + s.shadow, null);
        s.shadow = UUID.randomUUID();
        long m = s.shadow.getMostSignificantBits(), l = s.shadow.getLeastSignificantBits();
        String nbt = "{UUID:[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "],"
                + "profile:\"" + p.getGameProfile().name() + "\","
                + "immovable:1b,hide_description:1b,NoGravity:1b,Invulnerable:1b,Silent:1b,"
                + "Tags:[\"shadowmod\"]}";
        run("summon minecraft:mannequin " + f.x + " " + f.y + " " + f.z + " " + nbt, w);
    }

    void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            State s = STATES.get(p.getUuid());
            if (s == null) continue;
            ServerWorld w = (ServerWorld) p.getEntityWorld();

            Frame f = new Frame();
            f.x = p.getX(); f.y = p.getY(); f.z = p.getZ();
            f.yaw = p.getYaw(); f.pitch = p.getPitch();
            f.pose = p.getPose(); f.sneak = p.isSneaking(); f.sprint = p.isSprinting();
            f.swing = s.swing; s.swing = false;
            s.trail.addLast(f);
            while (s.trail.size() > s.delay + 1) s.trail.removeFirst();
            Frame t = s.trail.peekFirst();

            Entity e = s.shadow == null ? null : w.getEntity(s.shadow);
            if (e == null) {
                spawn(p, w, s, t);
                e = w.getEntity(s.shadow);
                if (e == null) continue;
            }

            double x = t.x, z = t.z; float yaw = t.yaw;
            if (s.mirror) { x = 2 * s.cx - t.x; z = 2 * s.cz - t.z; yaw = t.yaw + 180f; }

            e.teleport(w, x, t.y, z, Set.of(), yaw, t.pitch, false);
            e.setPose(t.pose);
            e.setSneaking(t.sneak);
            e.setSprinting(t.sprint);

            if (e instanceof LivingEntity le) {
                le.setHeadYaw(yaw);
                le.setBodyYaw(yaw);
                if (server.getTicks() % 10 == 0) {
                    for (EquipmentSlot slot : SLOTS) le.equipStack(slot, p.getEquippedStack(slot).copy());
                }
                if (t.swing) le.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    static State enable(ServerPlayerEntity p) {
        return STATES.computeIfAbsent(p.getUuid(), k -> new State());
    }

    void commands(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("shadow")
                // /shadow  = تشغيل / إيقاف
                .executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    if (STATES.containsKey(p.getUuid())) {
                        remove(p);
                        c.getSource().sendFeedback(() -> Text.literal("الظل راح"), false);
                    } else {
                        enable(p);
                        c.getSource().sendFeedback(() -> Text.literal("ظلك ظهر. يتبع حركاتك بعد ثانية"), false);
                    }
                    return 1;
                })
                // /shadow follow <تيك>  = يتبعك بتأخير
                .then(CommandManager.literal("follow")
                        .then(CommandManager.argument("ticks", IntegerArgumentType.integer(0, 200)).executes(c -> {
                            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                            State s = enable(p);
                            s.mirror = false;
                            s.delay = IntegerArgumentType.getInteger(c, "ticks");
                            c.getSource().sendFeedback(() -> Text.literal("الظل يتبعك بتأخير " + s.delay + " تيك"), false);
                            return 1;
                        })))
                // /shadow mirror  = انعكاس بالجهة المقابلة
                .then(CommandManager.literal("mirror").executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    State s = enable(p);
                    s.mirror = true;
                    s.delay = 0;
                    s.cx = p.getX(); s.cz = p.getZ();
                    c.getSource().sendFeedback(() -> Text.literal("وضع المرآة: الظل يسوي عكس حركتك"), false);
                    return 1;
                })));
    }
}
